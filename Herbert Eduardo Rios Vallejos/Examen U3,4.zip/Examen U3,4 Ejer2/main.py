class Interes:
    def __init__(self, P, r, t):
        self.P = P
        self.r = r / 100
        self.t = t

    def calcula_interes(self):
        pass

class InteresSimple(Interes):
    def calcula_interes(self):
        A = self.P * (1 + self.r * self.t)
        return A

class InteresCompuesto(Interes):
    def __init__(self, P, r, t, n):
        super().__init__(P, r, t)
        self.n = n

    def calcula_interes(self):
        A = self.P * (1 + self.r / self.n) ** (self.n * self.t)
        return A

P = float(input("Introduce la cantidad de dinero: "))
r = float(input("Introduce la tasa de interés %: "))
t = float(input("Introduce los años: "))
n = float(input("Introduce el número de veces que el interés se aplica por año: "))

interes_simple = InteresSimple(P, r, t)
interes_compuesto = InteresCompuesto(P, r, t, n)

print("Con interés simple, el capital se:", interes_simple.calcula_interes())
print("Con interés compuesto, el capital se:", interes_compuesto.calcula_interes())