def suma():
    a = float(input("Introduce el primer número: "))
    b = float(input("Introduce el segundo número: "))
    c = float(input("Introduce el tercer número: "))
    print("La suma es: ", a + b + c)

suma()
