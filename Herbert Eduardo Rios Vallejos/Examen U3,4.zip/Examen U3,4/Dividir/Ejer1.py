def dividir():
    a = int(input("Introduce el numerador: "))
    b = int(input("Introduce el denominador: "))
    if b == 0:
        print("Error: No se puede dividir por cero.")
    else:
        print("El resultado de la división es: ", a / b)

dividir()
