def triangulos():
    a = float(input("Introduce el primer lado: "))
    b = float(input("Introduce el segundo lado: "))
    c = float(input("Introduce el tercer lado: "))
    if a == b and b == c:
        print("El triángulo es equilátero")
    elif a == b or b == c or a == c:
        print("El triángulo es isósceles")
    else:
        print("El triángulo es escaleno")

triangulos()
