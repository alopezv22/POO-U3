import Area
import Dinero
import Calificaciones

def mostrar_menu():
    print("Bienvenido al Menú Principal")
    print("1. Calcular área de un triángulo")
    print("2. Calcular interés simple y compuesto")
    print("3. Representar información con gráficos de barras")
    print("Escribe 'EXIT' para salir del programa")

def ejecutar_programa(numero):
    if numero == '1':
        Area.CalcularArea
    elif numero == '2':
        Dinero.cantidad
    elif numero == '3':
        Calificaciones.alto_ventana
    else:
        print("Opción no válida")

if __name__ == "__main__":
    while True:
        mostrar_menu()
        opcion = input("Selecciona un programa (1, 2, 3) o escribe 'EXIT': ")
        
        if opcion.upper() == 'EXIT':
            print("Saliendo del menú...")
            break
        else:
            ejecutar_programa(opcion)