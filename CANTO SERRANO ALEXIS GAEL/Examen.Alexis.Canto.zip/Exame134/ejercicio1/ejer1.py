import math

class Triangulo:
    def _init_(self, a, b, angulo):
        self.a = a
        self.b = b
        self.angulo = angulo
        self.area = self.calcular_area()
        self.tipo = self.determinar_tipo()
        self.c = self.calcular_lado_c()

    def calcular_area(self):
        radianes = math.radians(self.angulo)
        return 0.5 * self.a * self.b * math.sin(radianes)

    def determinar_tipo(self):
        if self.a == self.b and self.angulo == 60:
            return "Equilátero"
        elif self.a == self.b or self.angulo == 90:
            return "Isósceles"
        else:
            return "Escaleno"

    def calcular_lado_c(self):
        c = math.sqrt(self.a*2 + self.b*2 - 2 * self.a * self.b * math.cos(math.radians(self.angulo)))
        return c

def calcular_triangulo():
    a = float(input("Ingrese la longitud del lado a en metros: "))
    b = float(input("Ingrese la longitud del lado b en metros: "))
    angulo = float(input("Ingrese el ángulo en grados que forman a y b: "))

    triangulo = Triangulo(a, b, angulo)

    print(f"El valor del área es: {triangulo.area} metros cuadrados")
    print(f"El triángulo es de tipo {triangulo.tipo}")
    print(f"La medida del tercer lado (c) es: {triangulo.c} metros")

def main():
    while True:
        print("Bienvenido al ejecicio de triangulos")
        print("1. Calcular un triángulo")
        print("2. Salir")
        opcion = input("Elija una opción: ")

        if opcion == '1':
            calcular_triangulo()
        elif opcion == '2':
            break
        else:
            print("Opción no válida. Por favor, elija una opción válida.")

if _name_ == "_main_":
    main()