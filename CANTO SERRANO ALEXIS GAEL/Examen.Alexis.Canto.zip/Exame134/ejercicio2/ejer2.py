class Interes:
    def _init_(self, capital, tasa, tiempo):
        self.capital = capital
        self.tasa = tasa
        self.tiempo = tiempo

    def calcular_interes(self):
        pass

class InteresSimple(Interes):
    def calcular_interes(self):
        interes = self.capital * (1 + (self.tasa / 100) * self.tiempo)
        return interes

class InteresCompuesto(Interes):
    def calcular_interes(self):
        interes = self.capital * (1 + (self.tasa / 100)) ** self.tiempo
        return interes

def calcular_interes():
    print("Bienvenido al programa de Interes")
    capital = float(input("Ingrese el capital inicial: "))
    tasa = float(input("Ingrese la tasa de interés (en porcentaje): "))
    tiempo = int(input("Ingrese el número de años: "))

    interes_simple = InteresSimple(capital, tasa, tiempo)
    interes_compuesto = InteresCompuesto(capital, tasa, tiempo)

    interes_simple_resultado = interes_simple.calcular_interes()
    interes_compuesto_resultado = interes_compuesto.calcular_interes()

    print(f'Con interés simple, el capital final es: {interes_simple_resultado:.2f}')
    print(f'Con interés compuesto, el capital final es: {interes_compuesto_resultado:.2f}')

if _name_ == "_main_":
    calcular_interes()