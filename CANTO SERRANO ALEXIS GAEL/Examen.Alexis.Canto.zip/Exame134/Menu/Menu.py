import tkinter as tk
import subprocess

def ejecutar_programa(paquete, programa):
    comando = ["python", "-m", f"{paquete}.{programa}"]
    subprocess.Popen(comando)

root = tk.Tk()
root.title("Menú de Programas")

def abrir_programa1():
    ejecutar_programa("ejer1", "ejer1")

def abrir_programa2():
    ejecutar_programa("ejer2", "ejer2")

def abrir_programa3():
    ejecutar_programa("ejer3", "ejer3")

def salir():
    root.destroy()

programa1_button = tk.Button(root, text="Programa 1", command=abrir_programa1)
programa1_button.pack()

programa2_button = tk.Button(root, text="Programa 2", command=abrir_programa2)
programa2_button.pack()

programa3_button = tk.Button(root, text="Programa 3", command=abrir_programa3)

programa3_button.pack()

exit_button = tk.Button(root, text="EXIT", command=salir)
exit_button.pack()

root.mainloop()