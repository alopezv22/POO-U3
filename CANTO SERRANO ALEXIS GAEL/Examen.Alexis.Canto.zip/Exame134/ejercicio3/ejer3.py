import tkinter as tk

def mostrar_grafico_barras(calificaciones):
    root = tk.Tk()
    root.title("Gráfico de Barras de Calificaciones")

    canvas = tk.Canvas(root, width=400, height=300)
    canvas.pack()

    max_value = 100  # Calificación máxima

    bar_width = 50
    x = 50

    for i, cantidad in enumerate(calificaciones, start=1):
        porcentaje = (cantidad / max_value) * 100
        bar_height = (porcentaje / 100) * 200
        canvas.create_rectangle(x, 250 - bar_height, x + bar_width, 250, fill='green')  # Cambiar el color a verde
        canvas.create_text(x + bar_width / 2, 260, text=f"Calif {i}: {porcentaje:.1f}%")
        x += 100

    root.mainloop()

def generar_grafico_desde_input():
    print("Bienvenido al programa de graficas")
    print("Ingrese el número de personas con cada una de las cuatro calificaciones (de 0 a 100):")
    calificaciones = [int(input(f"Calificación {i}: ")) for i in range(1, 5)]
    mostrar_grafico_barras(calificaciones)

if _name_ == "_main_":
    generar_grafico_desde_input()