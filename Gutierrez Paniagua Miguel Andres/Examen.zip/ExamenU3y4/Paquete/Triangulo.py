# Archivo: triangulo.py en el paquete Examen.Triangulo

import math

class Triangulo:
    def __init__(self, lado_a, lado_b, angulo):
        self.lado_a = lado_a
        self.lado_b = lado_b
        self.angulo = angulo

    def calcular_area(self):
        angulo_radianes = math.radians(self.angulo)
        area = 0.5 * self.lado_a * self.lado_b * math.sin(angulo_radianes)
        return area

    def tipo_triangulo(self):
        if self.lado_a == self.lado_b and self.angulo == 60:
            return "Equilátero"
        elif self.lado_a == self.lado_b or self.angulo == 90:
            return "Isósceles"
        else:
            return "Escaleno"

    def calcular_tercer_lado(self):
        angulo_radianes = math.radians(self.angulo)
        tercer_lado = math.sqrt(self.lado_a**2 + self.lado_b**2 - 2 * self.lado_a * self.lado_b * math.cos(angulo_radianes))
        return tercer_lado
