# Archivo: Calificaciones.py en el paquete Examen.Calificaciones

def main():
    calificaciones = ["Sobresaliente", "Notable", "Adecuado", "Insuficiente"]
    num_personas = []

    for calificacion in calificaciones:
        num = int(input(f"Número de personas con calificación {calificacion}: "))
        num_personas.append(num)

    print("\nDistribución de Calificaciones:")
    for i in range(len(calificaciones)):
        print(f"{calificaciones[i]}: {num_personas[i]} personas")
