# Archivo: interes.py en el paquete Examen.Interes

class Interes:
    def __init__(self, capital, tasa, tiempo):
        self.capital = capital
        self.tasa = tasa
        self.tiempo = tiempo

    def calcular_interes(self):
        pass

class InteresSimple(Interes):
    def calcular_interes(self):
        interes_simple = self.capital * self.tasa * self.tiempo
        return self.capital + interes_simple

class InteresCompuesto(Interes):
    def calcular_interes(self):
        interes_compuesto = self.capital * (1 + self.tasa) ** self.tiempo - self.capital
        return self.capital + interes_compuesto

