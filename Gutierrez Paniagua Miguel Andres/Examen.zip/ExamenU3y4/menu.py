from Paquete.Triangulo import Triangulo
from Paquete.Interes import InteresSimple, InteresCompuesto
from Paquete.Calificaciones import main as calificaciones_main

def menu():
    while True:
        print("Menú Principal")
        print("1. Triángulo")
        print("2. Interés")
        print("3. Calificaciones")
        print("4. EXIT")

        opcion = input("Elige una opción: ")

        if opcion == "1":
            print("Bienvenido al programa Triángulo")

            lado_a = float(input("Ingresa el valor del lado a (en metros): "))
            lado_b = float(input("Ingresa el valor del lado b (en metros): "))
            angulo = float(input("Ingresa el ángulo en grados: "))
            triangulo = Triangulo(lado_a, lado_b, angulo)
            print("a. El valor del área:", triangulo.calcular_area())
            print("b. Tipo de triángulo:", triangulo.tipo_triangulo())
            print("c. Medida del tercer lado:", triangulo.calcular_tercer_lado())

        elif opcion == "2":
            print("Bienvenido al programa Interés")
            capital = float(input("Ingresa la cantidad de dinero: "))
            tasa = float(input("Ingresa la tasa de interés (en decimal): "))
            tiempo = int(input("Ingresa el número de años: "))
            interes_simple = InteresSimple(capital, tasa, tiempo)
            interes_compuesto = InteresCompuesto(capital, tasa, tiempo)
            print("a. Interés Simple:", interes_simple.calcular_interes())
            print("b. Interés Compuesto:", interes_compuesto.calcular_interes())

        elif opcion == "3":
            print("Bienvenido al programa Calificaciones")
            calificaciones_main()

        elif opcion == "4" or opcion.upper() == "EXIT":
            break
        else:
            print("Opción no válida. Por favor, elige una opción válida.")

if __name__ == "__main__":
    menu()
