import math

class Triangulo:
    def __init__(self, lado_a, lado_b, angulo_grados):
        self.lado_a = lado_a
        self.lado_b = lado_b
        self.angulo_grados = angulo_grados

    def calcular_area(self):
        return 0.5 * self.lado_a * self.lado_b * math.sin(math.radians(self.angulo_grados))

    def tipo_de_triangulo(self):
        if self.lado_a == self.lado_b == (self.lado_a ** 2 + self.lado_b ** 2) ** 0.5:
            return "Triángulo Rectángulo"
        elif self.lado_a == self.lado_b:
            return "Triángulo Isósceles"
        elif self.lado_a != self.lado_b:
            return "Triángulo Escaleno"
        else:
            return "Triángulo Equilátero"

    def calcular_tercer_lado(self):
        angulo_radianes = math.radians(self.angulo_grados)
        tercer_lado = (self.lado_a ** 2 + self.lado_b ** 2 - 2 * self.lado_a * self.lado_b * math.cos(angulo_radianes)) ** 0.5
        return tercer_lado

def ejecutar():
    lado_a = float(input("Introduce la longitud del lado A en metros: "))
    lado_b = float(input("Introduce la longitud del lado B en metros: "))
    angulo_grados = float(input("Introduce el ángulo en grados: "))

    triangulo = Triangulo(lado_a, lado_b, angulo_grados)

    area = triangulo.calcular_area()
    tipo = triangulo.tipo_de_triangulo()
    tercer_lado = triangulo.calcular_tercer_lado()

    print(f"El área del triángulo es: {area} metros cuadrados")
    print(f"El triángulo es de tipo: {tipo}")
    print(f"La medida del tercer lado es: {tercer_lado} metros")

if __name__ == "__main__":
    ejecutar()
