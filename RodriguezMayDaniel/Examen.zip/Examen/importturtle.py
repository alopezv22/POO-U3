import turtle

def ejecutar():
    wn = turtle.Screen()
    wn.bgcolor("white")
    wn.title("Gráfico de Barras de Calificaciones")

    t = turtle.Turtle()
    t.speed(6)  

    sobresaliente = int(input("Número de personas con calificación sobresaliente: "))
    notable = int(input("Número de personas con calificación notable: "))
    adecuado = int(input("Número de personas con calificación adecuado: "))
    insuficiente = int(input("Número de personas con calificación insuficiente: "))

    ancho_barra = 50
    espacio_entre_barras = 60  
    altura_maxima = max(sobresaliente, notable, adecuado, insuficiente)
    altura_maxima += 80  

    def dibujar_barra(altura, etiqueta):
        t.begin_fill()
        t.color("blue")
        t.left(90)
        t.forward(altura)
        t.write(etiqueta, align="center", font=("Arial", 12, "normal"))  
        t.right(90)
        t.forward(ancho_barra)
        t.right(90)
        t.forward(altura)
        t.left(90)
        t.end_fill()

    t.penup()
    t.goto(-espacio_entre_barras * 3, -50)  
    t.pendown()
    dibujar_barra(sobresaliente, f"Sobresaliente\n({sobresaliente}%)")  

    t.penup()
    t.goto(-espacio_entre_barras, -50)  
    t.pendown()
    dibujar_barra(notable, f"Notable\n({notable}%)")

    t.penup()
    t.goto(espacio_entre_barras, -50)  
    t.pendown()
    dibujar_barra(adecuado, f"Adecuado\n({adecuado}%)")

    t.penup()
    t.goto(espacio_entre_barras * 3, -50)  
    t.pendown()
    dibujar_barra(insuficiente, f"Insuficiente\n({insuficiente}%)")

    wn.exitonclick()

if __name__ == "__main__":
    ejecutar()
