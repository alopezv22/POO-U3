def calcular_interes_simple(capital, tasa, años):
    monto = capital * (1 + tasa * años)
    return monto

def calcular_interes_compuesto(capital, tasa, años):
    monto = capital * (1 + tasa)**años
    return monto

def ejecutar():
    capital = float(input("Ingrese la cantidad de dinero inicial: "))
    tasa = float(input("Ingrese la tasa de interés (en decimal): "))
    años = int(input("Ingrese el número de años: "))

    monto_simple = calcular_interes_simple(capital, tasa, años)
    print(f"El monto final con interés simple es: ${monto_simple:.2f}")

    monto_compuesto = calcular_interes_compuesto(capital, tasa, años)
    print(f"El monto final con interés compuesto es: ${monto_compuesto:.2f")

if __name__ == "__main__":
    ejecutar()
