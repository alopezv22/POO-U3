import subprocess

while True:

    print("Selecciona una opción:")
    print("1. Ejecutar Programa 1")
    print("2. Ejecutar Programa 2")
    print("3. Ejecutar Programa 3")
    print("Para salir del programa, escribe EXIT ")

    # Obtener la selección del usuario
    opcion = input("Ingresa el número de la opción que deseas: ")

    # Procesar la selección del usuario
    if opcion == "1":
        subprocess.run(["python", "Examen ejercicio 1.py"])
    elif opcion == "2":
        subprocess.run(["python", "Examen ejercicio 2.py"])
    elif opcion == "3":
        subprocess.run(["python", "Examen ejercicio 3.py"])
    elif opcion == "EXIT":
        print("Saliendo del programa.")
        break
    else:
        print("Opción no válida. Por favor, selecciona una opción válida.")
