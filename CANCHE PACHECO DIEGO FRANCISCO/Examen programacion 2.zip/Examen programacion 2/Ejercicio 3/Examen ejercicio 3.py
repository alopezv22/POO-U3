import matplotlib.pyplot as plt

def ingresar_calificaciones():
    calificaciones = []
    for i in range(4):
        calificacion = int(input(f"Ingrese el número de personas con calificación {i + 1}: "))
        calificaciones.append(calificacion)
    return calificaciones

def grafico_de_barras(calificaciones):
    etiquetas = ["Calificación 1", "Calificación 2", "Calificación 3", "Calificación 4"]
    plt.bar(etiquetas, calificaciones)
    plt.xlabel("Calificaciones")
    plt.ylabel("Número de personas")
    plt.title("Distribución de Calificaciones")
    plt.show()

def main():
    calificaciones = ingresar_calificaciones()
    grafico_de_barras(calificaciones)

if __name__ == "__main__":
    main()
