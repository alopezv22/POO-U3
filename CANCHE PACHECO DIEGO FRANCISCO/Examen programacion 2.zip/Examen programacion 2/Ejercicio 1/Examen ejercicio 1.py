import math

class Triangulo:
    def __init__(self, lado_a, lado_b, angulo_grados):
        self.lado_a = lado_a
        self.lado_b = lado_b
        self.angulo_grados = angulo_grados

    def calcular_area(self):
        angulo_radianes = math.radians(self.angulo_grados)
        area = 0.5 * self.lado_a * self.lado_b * math.sin(angulo_radianes)
        return area

    def determinar_tipo(self):
        if self.lado_a == self.lado_b and self.angulo_grados == 60:
            return "Equilátero"
        elif self.lado_a == self.lado_b or self.angulo_grados == 90:
            return "Isósceles"
        else:
            return "Escaleno"

    def calcular_tercer_lado(self):
        angulo_radianes = math.radians(self.angulo_grados)
        lado_c = math.sqrt(self.lado_a**2 + self.lado_b**2 - 2 * self.lado_a * self.lado_b * math.cos(angulo_radianes))
        return lado_c


lado_a = float(input("Ingrese el valor del lado A (en metros): "))
lado_b = float(input("Ingrese el valor del lado B (en metros): "))
angulo_grados = float(input("Ingrese el ángulo (en grados) entre los lados A y B: "))

triangulo = Triangulo(lado_a, lado_b, angulo_grados)

area = triangulo.calcular_area()
tipo = triangulo.determinar_tipo()
lado_c = triangulo.calcular_tercer_lado()

print(f"El área del triángulo es {area} metros cuadrados.")
print(f"El triángulo es de tipo {tipo}.")
print(f"La medida del tercer lado es {lado_c} metros.")
