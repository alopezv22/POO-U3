
class Interes:
    def __init__(self, capital, tasa, años):
        self.capital = capital
        self.tasa = tasa
        self.años = años

    def calcular_interes(self):
        pass

class InteresSimple(Interes):
    def calcular_interes(self):
        interes = self.capital * (self.tasa / 100) * self.años
        return self.capital + interes

class InteresCompuesto(Interes):
    def calcular_interes(self):
        interes = self.capital * (1 + self.tasa / 100)**self.años - self.capital
        return self.capital + interes

def main():
    capital = float(input("Ingrese la cantidad de dinero: "))
    tasa = float(input("Ingrese la tasa de interés (en porcentaje): "))
    años = int(input("Ingrese el número de años: "))

    interes_simple = InteresSimple(capital, tasa, años)
    interes_compuesto = InteresCompuesto(capital, tasa, años)

    capital_simple = interes_simple.calcular_interes()
    capital_compuesto = interes_compuesto.calcular_interes()

    print(f"Después de {años} años, con interés simple, tendrás ${capital_simple:.2f}")
    print(f"Después de {años} años, con interés compuesto, tendrás ${capital_compuesto:.2f}")

if __name__ == "__main__":
    main()
