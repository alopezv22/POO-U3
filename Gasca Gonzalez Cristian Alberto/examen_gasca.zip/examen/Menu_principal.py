import area_triangulo, interes_compuesto_simple
print("Bienvenidos al Menu principal")
print("************************************")
print("1.- area del triangulo")
print("2.- interes compuesto")
print("3.- calificaciones")
print("4.- exit")
print("************************************")
    
op = int(input("Ingrese una opccion: "))

while op ==4:
    if op == 1:
        print("Bienvenido al programa Area del triangulo!!")
        area = area_triangulo()
    if op == 2:
        print("Bienvenido al programa Calculadora de interes compuesto!!")
        calcular = interes_compuesto_simple

    