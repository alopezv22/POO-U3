import math
class triangulo():
    def __init__(self, a, b, c):
        self.a = a
        self.b = b
        self.c = c
    
    def imprimir(self):
        return print("Lado a: ", a,  "Lado b: ", b, "Lado c: ", c)
    pass

class tercer_lado(triangulo):
    def __init__(self, a, b, c):
        super().__init__(a, b, c)
        self.c = c
        c = math.sqrt(a*a + b*b)
        return print("El tercer lado mide: ", c)
   
    pass
    
class area(triangulo):
    def __init__(self, a, b, Ar):
        super().__init__(a, b, c)
        self.Ar = Ar
        radianes = (ang*math.pi)/180
        Ar = (1/2 * (a*b)) * (math.sin(radianes))
        return print("El area es: ", Ar)
    pass

class tipo_triangulo(triangulo): 
    def __init__(self, a, b, c):
        super().__init__(a, b, c)   
        if a==b and b ==c:
            print("Es un trianguo equilatero")
        if a==b and a!=c:
            print("Es un triangulo isoceles")
        if a!=b and a!=c:
            print("Es un triangulo escaleno")
            

print("************************************************************")
a = int(input("Ingresa el la longitud del lado a: "))
b = int(input("Ingresa el la longitud del lado b: "))
c = 0
ang= int(input("Ingrese el angulo: "))

Mi_triangulo = triangulo(a, b, c)
Mi_area = area(a, b, ang)
Mi_tercelado = tercer_lado(a,b, c)
Mi_tipo = tipo_triangulo(a, b, c)
print("*************************************************************")