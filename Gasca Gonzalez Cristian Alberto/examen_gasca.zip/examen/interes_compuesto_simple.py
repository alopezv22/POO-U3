def interes_compuestos():
    class interes():
        def __init__(self, capital, años) -> None:
            self.capital = capital 
            self.años = años
            self.interes = interess
            print("La tasa de interes es de: ", self.interes, "%")

            pass
        
        def calcular_interes_simple(self):
            self.interes_simple = self.capital * self.interes * self.años
            return print("El interes simple es: ", self.interes_simple)
        def calcular_interes(self):
            self.interes = self.interes/100
            self.itotal = self.interes * self.capital
            self.caconi = self.capital + self.itotal
            c = 1 
            while c < self.años:
                self.itotal = self.interes * self.caconi
                self.caconi = self.itotal + self.caconi
                c = c +1
            print("El incremento total en el periodo de", self.años, " es de: ", self.caconi, "pesos")
        
                
    print("            Calculadora de interes compuesto")
    print("*****************************************************")
    capital = int(input("Ingrese el capital total: "))
    años = int(input("Ingrese el total de años: "))
    interess = int(input("Ingrese la tasa de interes: "))
    micapital = interes(capital, años)
    micapital.calcular_interes()
    micapital.calcular_interes_simple()
    print("*****************************************************")

    