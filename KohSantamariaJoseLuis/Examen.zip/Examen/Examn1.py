


import math

class Triangulo:
    def __init__(self, lado_a, lado_b, angulo_grados):
        self.lado_a = lado_a
        self.lado_b = lado_b
        self.angulo_radianes = math.radians(angulo_grados)
    
    def calcular_area(self):
        return 0.5 * self.lado_a * self.lado_b * math.sin(self.angulo_radianes)
    
    def tipo_de_triangulo(self):
        if math.isclose(self.lado_a, self.lado_b, rel_tol=1e-9) and math.isclose(self.angulo_radianes, math.pi/3, rel_tol=1e-9):
            return "Equilátero"
        elif math.isclose(self.lado_a, self.lado_b, rel_tol=1e-9) or math.isclose(self.angulo_radianes, math.pi/3, rel_tol=1e-9):
            return "Isósceles"
        else:
            return "Escaleno"
    
    def calcular_tercer_lado(self):
        return math.sqrt(self.lado_a**2 + self.lado_b**2 - 2 * self.lado_a * self.lado_b * math.cos(self.angulo_radianes))

def main():
    lado_a, lado_b, angulo_grados = map(float, input("Ingrese lado a, lado b y ángulo en grados separados por espacios: ").split())
    
    triangulo = Triangulo(lado_a, lado_b, angulo_grados)
    
    area = triangulo.calcular_area()
    tipo = triangulo.tipo_de_triangulo()
    tercer_lado = triangulo.calcular_tercer_lado()
    
    print(f"Área del triángulo: {area} metros cuadrados")
    print(f"Tipo de triángulo: {tipo}")
    print(f"Longitud del tercer lado: {tercer_lado} metros")

if __name__ == "__main__":
    main()
