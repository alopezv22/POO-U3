

# programa_tres.py

def ejecutar():
    print("Bienvenido al programa Tres")
    # Lógica del programa Tres

   
