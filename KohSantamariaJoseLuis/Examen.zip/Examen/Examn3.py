

import turtle

def ejecutar():
    def dibujar_barra(t, altura):
        """ Dibuja una barra con la altura dada. """
        t.begin_fill()              
        t.left(90)
        t.forward(altura)            
        t.write(" " + str(altura))   
        t.right(90)
        t.forward(40)                
        t.right(90)
        t.forward(altura)            
        t.left(90)
        t.end_fill()                 
        t.forward(10)                

    def solicitar_datos():
        sobresaliente_count = int(input('Introduce el número de personas con calificación Sobresaliente: '))
        notable_count = int(input('Introduce el número de personas con calificación Notable: '))
        adecuado_count = int(input('Introduce el número de personas con calificación Adecuado: '))
        insuficiente_count = int(input('Introduce el número de personas con calificación Insuficiente: '))

        total_count = sobresaliente_count + notable_count + adecuado_count + insuficiente_count

        if total_count == 0:
            return [0, 0, 0, 0]

        sobresaliente_pct = (sobresaliente_count / total_count) * 100
        notable_pct = (notable_count / total_count) * 100
        adecuado_pct = (adecuado_count / total_count) * 100
        insuficiente_pct = (insuficiente_count / total_count) * 100

        return [sobresaliente_pct, notable_pct, adecuado_pct, insuficiente_pct]

    percentajes = solicitar_datos()

    wn = turtle.Screen()  
    wn.bgcolor("white")   
    wn.title("Gráfico de barras con Turtle")

    grafico_barras = turtle.Turtle()
    grafico_barras.color("blue")
    grafico_barras.fillcolor("blue")

    grafico_barras.penup()
    grafico_barras.goto(-100, -150)
    grafico_barras.pendown()

    for i in range(len(percentajes)):
        dibujar_barra(grafico_barras, percentajes[i])

    wn.mainloop()

# Si este módulo es el principal, ejecuta la función.
if __name__ == '__main__':
    ejecutar()
