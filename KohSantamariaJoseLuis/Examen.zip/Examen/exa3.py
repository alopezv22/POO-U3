
# Examn3.py

def ejecutar():
    print("Bienvenido al programa Tres")
    # Aquí va el resto del código de tu programa tres
