
class CalculadoraInteres:
    def __init__(self, capital, tasa, años):
        self.capital = capital
        self.tasa = tasa
        self.años = años

    def calcular_interes(self):
        pass

class InteresSimple(CalculadoraInteres):
    def calcular_interes(self):
        interes = self.capital * (1 + (self.tasa / 100) * self.años)
        return interes

class InteresCompuesto(CalculadoraInteres):
    def calcular_interes(self):
        interes = self.capital * (1 + self.tasa / 100) ** self.años
        return interes

def main():
    try:
        capital = float(input("Ingrese la cantidad de dinero: "))
        tasa = float(input("Ingrese la tasa de interés (en porcentaje): "))
        años = int(input("Ingrese el número de años: "))
    except ValueError:
        print("Entrada no válida. Asegúrese de ingresar números válidos.")
        return

    calculadora_simple = InteresSimple(capital, tasa, años)
    calculadora_compuesto = InteresCompuesto(capital, tasa, años)

    interes_simple = calculadora_simple.calcular_interes()
    interes_compuesto = calculadora_compuesto.calcular_interes()

    print(f"Interés Simple después de {años} años: ${interes_simple:.2f}")
    print(f"Interés Compuesto después de {años} años: ${interes_compuesto:.2f}")

if __name__ == "__main__":
    main()


