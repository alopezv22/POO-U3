
def main_menu():
    while True:
        print("Bienvenido al menú principal. Selecciona una opción:")
        print("1. Programa Uno")
        print("2. Programa Dos")
        print("3. Programa Tres")
        print("Escribe 'EXIT' para salir.")
        
        user_input = input("> ").strip().upper()
        
        if user_input == "1":
            # Asumiendo que hay un módulo llamado 'programa_uno' con una función 'ejecutar'
            import Examn1
            Examn1.ejecutar()
        elif user_input == "2":
            # Asumiendo que hay un módulo llamado 'programa_dos' con una función 'ejecutar'
            import Examn2
            Examn2.ejecutar()
        elif user_input == "3":
            # Asumiendo que hay un módulo llamado 'programa_tres' con una función 'ejecutar'
            import Examn3
            Examn3.ejecutar()
        elif user_input == "EXIT":
            print("Saliendo del programa...")
            break
        else:
            print("Opción no reconocida. Intenta de nuevo.")

if __name__ == "__main__":
    main_menu()
