import math

class Area:
    def __init__(self, a, b, theta):
        self.a = a
        self.b = b
        self.theta = theta

    def calcular_area(self):
        theta_rad = math.radians(self.theta)
        area = 0.5 * self.a * self.b * math.sin(theta_rad)
        return area

class TipoTriangulo:
    def __init__(self, a, b):
        self.a = a
        self.b = b

    def determinar_tipo(self):
        if self.a == self.b:
            return 'Isósceles'
        elif self.a != self.b and self.a != self.c and self.b != self.c:
            return 'Escaleno'
        else:
            return 'Equilátero'

class TercerLado:
    def __init__(self, a, b, theta):
        self.a = a
        self.b = b
        self.theta = theta

    def calcular_lado(self):
        theta_rad = math.radians(self.theta)
        c = math.sqrt(self.a**2 + self.b**2 - 2*self.a*self.b*math.cos(theta_rad))
        return c

def main():
    a = float(input("Introduce el valor del primer lado (en metros): "))
    b = float(input("Introduce el valor del segundo lado (en metros): "))
    theta = float(input("Introduce el valor del ángulo (en grados): "))

    triangulo = Area(a, b, theta)
    print("El valor del área es: ", triangulo.calcular_area())

    tipo = TipoTriangulo(a, b)
    print("El tipo de triángulo es: ", tipo.determinar_tipo())

    lado = TercerLado(a, b, theta)
    print("La medida del tercer lado es: ", lado.calcular_lado())

if __name__ == "__main__":
    main()