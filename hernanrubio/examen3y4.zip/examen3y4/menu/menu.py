from programa1
from programa2
def menu():
    while True:
        print("Bienvenido al menú principal. Por favor, elige una opción:")
        print("1. Ejecutar el programa 1")
        print("2. Ejecutar el programa 2")
        print("Escribe 'EXIT' para salir")

        opcion = input()

        if opcion == '1':
            print("Bienvenido al programa 1")
            ejer1()
        elif opcion == '2':
            print("Bienvenido al programa 2")
            ejer2()
        elif opcion.upper() == 'EXIT':
            break
        else:
            print("Opción no reconocida. Por favor, intenta de nuevo.")

if __name__ == "__main__":
    menu()
