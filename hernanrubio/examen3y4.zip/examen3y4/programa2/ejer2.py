class Interes:
    def __init__(self, capital, tasa, años):
        self.capital = capital
        self.tasa = tasa
        self.años = años

    def calcular_interes(self):
        pass

class InteresSimple(Interes):
    def calcular_interes(self):
        return self.capital * (1 + self.tasa * self.años)

class InteresCompuesto(Interes):
    def calcular_interes(self):
        return self.capital * (1 + self.tasa)**self.años

def main():
    capital = float(input("Introduce la cantidad de dinero: "))
    tasa = float(input("Introduce la tasa de interés: "))
    años = int(input("Introduce el número de años: "))

    interes_simple = InteresSimple(capital, tasa, años)
    print("El capital inicial se convertirá en ", interes_simple.calcular_interes(), " con interés simple.")

    interes_compuesto = InteresCompuesto(capital, tasa, años)
    print("El capital inicial se convertirá en ", interes_compuesto.calcular_interes(), " con interés compuesto.")

if __name__ == "__main__":
    main()