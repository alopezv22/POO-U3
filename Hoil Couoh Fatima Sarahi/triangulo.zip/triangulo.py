import math

class Triangulo:
    def _init_(self, a, b, theta):
        self.a = a
        self.b = b
        self.theta = math.radians(theta)
        self.c = None

    def calcular_area(self):
        return 0.5 * self.a * self.b * math.sin(self.theta)

    def calcular_tamaño_del_tercer_lado(self):
        self.c = math.sqrt(self.a*2 + self.b*2 - 2 * self.a * self.b * math.cos(self.theta))
        return self.c

    def tipo_de_triangulo(self):
        if self.a == self.b and self.b == self.c:
            return "Equilátero"
        elif self.a == self.b or self.a == self.c or self.b == self.c:
            return "Isósceles"
        else:
            return "Escaleno"

def main():
    a = float(input("Ingrese el valor del primer lado (en metros): "))
    b = float(input("Ingrese el valor del segundo lado (en metros): "))
    theta = float(input("Ingrese el ángulo entre los lados (en grados): "))

    triangulo = Triangulo(a, b, theta)
    tercer_lado = triangulo.calcular_tamaño_del_tercer_lado()  

    area = triangulo.calcular_area()
    tipo = triangulo.tipo_de_triangulo()

    print(f"El área del triángulo es: {area} metros cuadrados")
    print(f"El triángulo es de tipo: {tipo}")
    print(f"La medida del tercer lado es: {tercer_lado} metros")

if __name__ == "_main_":
    main()