class Interes:
    def __init__(self, capital, tasa_interes, tiempo):
        self.capital = capital
        self.tasa_interes = tasa_interes
        self.tiempo = tiempo

    def interes_simple(self):
        interes = self.capital * self.tasa_interes * self.tiempo
        return self.capital + interes

    def interes_compuesto(self):
        interes = self.capital * ((1 + self.tasa_interes) ** self.tiempo - 1)
        return self.capital + interes

class Herencia(Interes):
    def __init__(self, capital, tasa_interes, tiempo):
        super().__init__(capital, tasa_interes, tiempo)

    def interes_simple(self):
        interes = self.capital * self.tasa_interes * self.tiempo
        return self.capital + interes

    def interes_compuesto(self):
        interes = self.capital * ((1 + self.tasa_interes) ** self.tiempo - 1)
        return self.capital + interes

if __name__ == '__main__':
    capital = float(input("Ingrese la cantidad de dinero: "))
    tasa_interes = float(input("Ingrese la tasa de interés: "))
    tiempo = int(input("Ingrese el número de años: "))

    interes = Interes(capital, tasa_interes, tiempo)
    herencia = Herencia(capital, tasa_interes, tiempo)

    print(f"El capital inicial de {capital} transcurridos {tiempo} años con una tasa de interés del {tasa_interes} % aplicando la fórmula del interés simple es de {interes.interes_simple()} y aplicando la fórmula del interés compuesto es de {herencia.interes_compuesto()}.")
