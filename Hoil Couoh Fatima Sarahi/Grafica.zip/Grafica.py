import matplotlib.pyplot as plt


calificacion_1 = int(input("Número de personas con calificación 1: "))
calificacion_2 = int(input("Número de personas con calificación 2: "))
calificacion_3 = int(input("Número de personas con calificación 3: "))
calificacion_4 = int(input("Número de personas con calificación 4: "))

calificaciones = [1, 2, 3, 4]
cantidad_personas = [calificacion_1, calificacion_2, calificacion_3, calificacion_4]

plt.bar(calificaciones, cantidad_personas)
plt.xlabel('Calificación')
plt.ylabel('Número de Personas')
plt.title('Distribución de Calificaciones')

plt.show()
