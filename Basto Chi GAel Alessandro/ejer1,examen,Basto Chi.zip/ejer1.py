import turtle
import math

class GraficoBarrasTurtle:
    def __init__(self):
        # Solicitar el número de personas con cada calificación
        calificaciones = ['Excelente', 'Bueno', 'Regular', 'Deficiente']
        num_personas = []

        for calificacion in calificaciones:
            num = int(input(f'Número de personas con calificación "{calificacion}": '))
            num_personas.append(num)

        # Calcular el porcentaje de cada calificación
        total_personas = sum(num_personas)
        porcentajes = [(num / total_personas) * 100 for num in num_personas]

        # Crear una ventana gráfica
        wn = turtle.Screen()
        wn.title('Gráfico de Barras')

        # Configurar la pluma de Turtle
        pen = turtle.Turtle()
        pen.speed(5)
        pen.penup()
        pen.goto(-150, -100)
        pen.pendown()

        # Crear el gráfico de barras
        bar_width = 40
        bar_spacing = 60  # Espacio entre las barras
        label_offset = 20  # Espacio entre la barra y la etiqueta
        percentage_offset = 50  # Espacio entre la barra y el porcentaje

        for i, calificacion in enumerate(calificaciones):
            # Dibuja la barra
            pen.fillcolor('skyblue')
            pen.begin_fill()
            pen.forward(bar_width)
            pen.left(90)
            pen.forward(porcentajes[i] * 2)
            pen.left(90)
            pen.forward(bar_width)
            pen.left(90)
            pen.forward(porcentajes[i] * 2)
            pen.left(90)
            pen.end_fill()

            # Etiqueta de la calificación debajo de la barra
            pen.penup()
            pen.goto(pen.xcor() - bar_width / 2, pen.ycor() - label_offset)
            pen.pendown()
            pen.write(f'{calificacion}', align='center', font=('Arial', 12, 'normal'))
            pen.penup()

            # Porcentaje encima de la barra
            pen.goto(pen.xcor() - bar_width / 2, pen.ycor() + porcentajes[i] + percentage_offset)
            pen.pendown()
            pen.write(f'{porcentajes[i]:.2f}%', align='center', font=('Arial', 10, 'normal'))
            pen.penup()

            # Mover a la posición de la siguiente barra con más espacio
            pen.goto(pen.xcor() + bar_width + bar_spacing, -100)
            pen.pendown()

        # Mostrar el gráfico
        wn.mainloop()

class Triangulo:
    def __init__(self, lado1, lado2, angulo):
        self.lado1 = lado1
        self.lado2 = lado2
        self.angulo = math.radians(angulo)

    def calcular_area(self):
        area = 0.5 * self.lado1 * self.lado2 * math.sin(self.angulo)
        return area

class TipoTriangulo:
    def __init__(self, lado1, lado2, angulo):
        self.lado1 = lado1
        self.lado2 = lado2
        self.angulo = angulo

    def determinar_tipo(self):
        if self.lado1 == self.lado2 and self.angulo == 60:
            return "Equilátero"
        elif self.lado1 != self.lado2 and self.angulo != 60:
            return "Escaleno"
        else:
            return "Isósceles"

class TercerLado:
    def __init__(self, lado1, lado2, angulo):
        self.lado1 = lado1
        self.lado2 = lado2
        self.angulo = angulo

    def calcular_tercer_lado(self):
        radianes = math.radians(self.angulo)
        tercer_lado = math.sqrt(self.lado1**2 + self.lado2**2 - 2 * self.lado1 * self.lado2 * math.cos(radianes))
        return tercer_lado

class Interes:
    def __init__(self, capital, tasa, tiempo):
        self.capital = capital
        self.tasa = tasa
        self.tiempo = tiempo

    def calcular_monto_final(self):
        pass

class InteresSimple(Interes):
    def calcular_monto_final(self):
        monto = self.capital * (1 + self.tasa * self.tiempo)
        return monto

class InteresCompuesto(Interes):
    def calcular_monto_final(self):
        monto = self.capital * (1 + self.tasa) ** self.tiempo
        return monto

def main():
    while True:
        print("Selecciona un programa:")
        print("1. Gráfico de Barras con Turtle")
        print("2. Cálculo de Área de Triángulo")
        print("3. Cálculo de Interés")
        print("4. Salir")

        opcion = input("Ingresa el número del programa que deseas ejecutar: ")

        if opcion == '1':
            grafico = GraficoBarrasTurtle()
        elif opcion == '2':
            area_triangulo = CalculoAreaTriangulo(Triangulo, TercerLado, TipoTriangulo)
        elif opcion == '3':
            calculo_interes = CalculoInteres(InteresSimple, InteresCompuesto)
        elif opcion == '4':
            print("¡Adiós!")
            break
        else:
            print("Opción no válida. Por favor, elige una opción válida.")

if __name__ == "__main__":
    main()
